#cmakedefine JPGALLEG_MMX
